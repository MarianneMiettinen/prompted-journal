
  # High-fidelity journaling app

  This is a code bundle for High-fidelity journaling app. The original project is available at https://www.figma.com/design/IhhwhyR7FffdYVvlYWnGMH/High-fidelity-journaling-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  