export default function IPhone() {
  return (
    <div className="bg-white relative size-full" data-name="iPhone 16 - 6">
      <div className="absolute flex h-[851px] items-center justify-center left-[7px] top-0 w-[371px]">
        <div className="flex-none rotate-[-66.44deg]">
          <div className="h-0 relative w-[928.354px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" height="1" preserveAspectRatio="none" viewBox="0 0 928.354 1" width="928.354">
                <line id="Line 462" stroke="black" x2="928.354" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[104px] leading-[normal] left-[95px] not-italic text-[24px] text-black top-[294px] w-[239px]">illustration of what was inside the gift / a magic crystal ball</p>
      <div className="absolute bg-[#1b1624] h-[42px] left-[127px] rounded-[40px] top-[726px] w-[139px]" />
    </div>
  );
}