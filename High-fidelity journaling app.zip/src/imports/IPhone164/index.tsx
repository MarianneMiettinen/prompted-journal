export default function IPhone() {
  return (
    <div className="bg-white relative size-full" data-name="iPhone 16 - 4">
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[104px] leading-[normal] left-[67px] not-italic text-[24px] text-black top-[270px] w-[239px]">illusration of wizard doing magic</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[104px] leading-[normal] left-[67px] not-italic text-[24px] text-black top-[270px] w-[239px]">illusration of wizard doing magic</p>
      <div className="absolute bg-[#1b1624] h-[42px] left-[127px] rounded-[40px] top-[726px] w-[139px]" />
    </div>
  );
}