export default function IPhone() {
  return (
    <div className="relative size-full" data-name="iPhone 16 - 3">
      <svg className="absolute block inset-0 size-full" fill="none" height="852" preserveAspectRatio="none" viewBox="0 0 393 852" width="393">
        <g id="iPhone 16 - 3">
          <rect fill="white" height="852" width="393" />
          <rect fill="#D9D9D9" height="796" id="Rectangle 444" width="393" y="4" />
          <rect fill="#1B1624" height="29" id="Rectangle 437" width="253" x="70" y="53" />
          <rect fill="#F9F6F3" height="182" id="Rectangle 445" width="333" x="30" y="146" />
          <circle cx="318.5" cy="305.5" fill="#D9D9D9" id="Ellipse 208" r="22.5" />
          <line id="Line 454" stroke="black" x1="306.348" x2="341.348" y1="293.641" y2="327.641" />
          <line id="Line 455" stroke="black" x1="305.675" x2="340.675" y1="323.62" y2="293.62" />
          <line id="Line 456" stroke="black" strokeWidth="4" x1="69" x2="69" y1="178" y2="216" />
          <rect fill="#76737C" height="307" id="Rectangle 446" width="378" x="4" y="493" />
        </g>
      </svg>
    </div>
  );
}