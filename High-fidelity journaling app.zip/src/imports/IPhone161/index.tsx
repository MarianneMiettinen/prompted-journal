export default function IPhone() {
  return (
    <div className="bg-white relative size-full" data-name="iPhone 16 - 1">
      <div className="absolute bg-[#d9d9d9] h-[440px] left-px top-[361px] w-[392px]" />
      <div className="absolute bg-[#f9f6f3] h-[111px] left-[14px] top-[426px] w-[364px]" />
      <div className="absolute bg-[#f9f6f3] h-[111px] left-[14px] top-[426px] w-[364px]" />
      <div className="absolute bg-[#f9f6f3] h-[111px] left-[14px] top-[549px] w-[364px]" />
      <div className="absolute bg-[#f9f6f3] h-[111px] left-[14px] top-[672px] w-[364px]" />
      <div className="absolute bg-black h-[31px] left-[39px] top-[450px] w-[41px]" />
      <div className="absolute bg-black h-[31px] left-[39px] top-[573px] w-[41px]" />
      <div className="absolute bg-black h-[31px] left-[39px] top-[696px] w-[41px]" />
      <div className="absolute bg-[#1b1624] h-[29px] left-[95px] top-[452px] w-[253px]" />
      <div className="absolute bg-[#1b1624] h-[29px] left-[95px] top-[575px] w-[253px]" />
      <div className="absolute bg-[#1b1624] h-[29px] left-[95px] top-[698px] w-[253px]" />
    </div>
  );
}