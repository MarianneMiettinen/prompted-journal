export default function IPhone() {
  return (
    <div className="relative size-full" data-name="iPhone 16 - 2">
      <svg className="absolute block inset-0 size-full" fill="none" height="852" preserveAspectRatio="none" viewBox="0 0 393 852" width="393">
        <g clipPath="url(#clip0_0_4)" id="iPhone 16 - 2">
          <rect fill="white" height="852" width="393" />
          <line id="Line 449" stroke="black" x2="389" y1="802.5" y2="802.5" />
          <line id="Line 450" stroke="black" x1="2" y1="212.5" y2="212.5" />
          <line id="Line 451" stroke="black" x2="389" y1="240.5" y2="240.5" />
          <line id="Line 452" stroke="black" x1="2.25918" x2="393.259" y1="3.57242" y2="240.572" />
          <rect fill="#1B1624" height="29" id="Rectangle 437" width="253" x="68" y="260" />
          <rect fill="#D9D9D9" height="478" id="Rectangle 438" width="393" y="325" />
          <rect fill="#1B1624" height="55" id="Rectangle 439" rx="27.5" width="157" x="47" y="371" />
          <rect fill="#1B1624" height="55" id="Rectangle 440" rx="27.5" width="157" x="66" y="445" />
          <rect fill="#1B1624" height="55" id="Rectangle 441" rx="27.5" width="157" x="60" y="527" />
          <rect fill="#1B1624" height="55" id="Rectangle 442" rx="27.5" width="157" x="66" y="593" />
          <rect fill="#1B1624" height="55" id="Rectangle 443" rx="27.5" width="157" x="217" y="371" />
          <ellipse cx="88.5" cy="398.5" fill="#FFCC4D" id="Ellipse 203" rx="20.5" ry="19.5" />
          <ellipse cx="107.5" cy="472.5" fill="#FFCC4D" id="Ellipse 204" rx="20.5" ry="19.5" />
          <ellipse cx="107.5" cy="546.5" fill="#FFCC4D" id="Ellipse 205" rx="20.5" ry="19.5" />
          <ellipse cx="107.5" cy="620.5" fill="#FFCC4D" id="Ellipse 206" rx="20.5" ry="19.5" />
          <ellipse cx="258.5" cy="398.5" fill="#FFCC4D" id="Ellipse 207" rx="20.5" ry="19.5" />
        </g>
        <defs>
          <clipPath id="clip0_0_4">
            <rect fill="white" height="852" width="393" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}