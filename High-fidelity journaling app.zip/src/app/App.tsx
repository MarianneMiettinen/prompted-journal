import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ArrowRight } from "lucide-react";
import gongImage from "@/imports/ee15859d-69e8-4fe4-b9bc-f48d0cd1ad06.png";

// ─── Types ────────────────────────────────────────────────────────────────────

type Step =
  | "mood"
  | "question"
  | "journal"
  | "wizard"
  | "gift"
  | "reveal"
  | "cupboard"
  | "spell"
  | "gong"
  | "med-reveal"
  | "final-cupboard";

interface Emotion {
  id: string;
  emoji: string;
  label: string;
  crystal: { color: string; name: string; description: string };
  question: string;
  options: string[];
  prompt: string;
}

interface Crystal {
  color: string;
  name: string;
  day?: string;
  isNew?: boolean;
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const EMOTIONS: Emotion[] = [
  {
    id: "happy", emoji: "😊", label: "Happy",
    crystal: { color: "#FCD34D", name: "Sunstone", description: "The warmth of today's happiness, preserved forever." },
    question: "What's bringing you joy right now?",
    options: ["Something good that happened", "Someone I care about", "Something I'm proud of", "I just feel light inside"],
    prompt: "Describe what's making you happy today. Write about the details, the feeling, and what it means to you.",
  },
  {
    id: "sad", emoji: "😢", label: "Sad",
    crystal: { color: "#93C5FD", name: "Moonpearl", description: "Your tears are proof of how deeply you care. This holds that." },
    question: "What's weighing on your heart today?",
    options: ["Something that happened", "I'm missing someone", "I feel lost or stuck", "I'm not sure why"],
    prompt: "Let it all out here. Write what's sitting heavy on you. This space is only for you.",
  },
  {
    id: "anxious", emoji: "😰", label: "Anxious",
    crystal: { color: "#C4B5FD", name: "Serenite", description: "A moment of calm, captured from the storm you are weathering." },
    question: "What feels uncertain right now?",
    options: ["Something coming up soon", "A relationship", "Work or responsibilities", "Something I cannot control"],
    prompt: "Name what's making you anxious. Sometimes fears shrink when we look at them directly.",
  },
  {
    id: "angry", emoji: "😠", label: "Angry",
    crystal: { color: "#FCA5A5", name: "Emberstone", description: "Your fire, witnessed and honored. Anger knows what matters to you." },
    question: "What sparked this feeling?",
    options: ["An unfair situation", "I felt misunderstood", "A boundary was crossed", "Something I did myself"],
    prompt: "Write about what happened. All of it — the full picture, what you felt, what you needed.",
  },
  {
    id: "calm", emoji: "😌", label: "Calm",
    crystal: { color: "#86EFAC", name: "Verdancite", description: "A pocket of stillness, to return to whenever things get loud." },
    question: "What brought you to this peaceful place?",
    options: ["Time to myself", "Something I completed", "Being in nature", "Just breathing slowly"],
    prompt: "Stay in this feeling. Write about what calm feels like in your body and mind right now.",
  },
  {
    id: "overwhelmed", emoji: "🥺", label: "Overwhelmed",
    crystal: { color: "#FDBA74", name: "Amberglow", description: "Your carried weight, seen and honored exactly as it is." },
    question: "What feels like too much right now?",
    options: ["Too many tasks", "Too many people's needs", "Too many expectations", "Too many feelings at once"],
    prompt: "Put everything down on this page. You don't have to fix anything. Just write it.",
  },
  {
    id: "lonely", emoji: "😔", label: "Lonely",
    crystal: { color: "#F0ABFC", name: "Rosegem", description: "A reminder, sealed in crystal, that you are never truly alone." },
    question: "What kind of connection are you missing?",
    options: ["A specific person", "A sense of belonging", "Feeling truly seen", "Just having company"],
    prompt: "Write about who or what you're missing. What would connection feel like for you right now?",
  },
  {
    id: "excited", emoji: "🤩", label: "Excited",
    crystal: { color: "#6EE7B7", name: "Aurorite", description: "Your spark, crystallized at its most alive." },
    question: "What's got you buzzing?",
    options: ["Something happening soon", "A new idea or project", "A breakthrough I had", "Life just feels good"],
    prompt: "Let yourself be as enthusiastic as you feel. Write it all — the excitement, the vision.",
  },
  {
    id: "numb", emoji: "😐", label: "Numb",
    crystal: { color: "#CBD5E1", name: "Clearstone", description: "Even still water holds something true beneath the surface." },
    question: "When did this feeling begin?",
    options: ["Just today", "A few days ago", "It has been a while", "I honestly can't remember"],
    prompt: "Even numbness has something underneath it. Write anything — a word, a colour, a memory. Start anywhere.",
  },
];

const PRIOR_CRYSTALS: Crystal[] = [
  { color: "#86EFAC", name: "Verdancite", day: "Mon" },
  { color: "#93C5FD", name: "Moonpearl", day: "Tue" },
  { color: "#FCD34D", name: "Sunstone", day: "Wed" },
];

const MED_CRYSTAL_POOL = [
  { color: "#7C6FF7", name: "Resonite", description: "Born from ninety seconds of stillness. Your breath gave this crystal its power." },
  { color: "#A78BFA", name: "Stillite", description: "Ninety seconds of presence, crystallized for always." },
  { color: "#818CF8", name: "Vibrastone", description: "The gong's vibration lives inside this now, forever." },
];

const PRIOR_MED_CRYSTALS: Crystal[] = [
  { color: "#A78BFA", name: "Stillite", day: "Mon" },
];

const GRID: React.CSSProperties = {
  backgroundImage:
    "linear-gradient(to right, rgba(147,197,253,0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(147,197,253,0.1) 1px, transparent 1px)",
  backgroundSize: "28px 28px",
  backgroundColor: "#FDFCF8",
};

const SLIDE = {
  enter: { opacity: 0, x: 28 },
  center: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -28 },
};

// ─── Wizard SVG ───────────────────────────────────────────────────────────────

function WizardSVG({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 120 152" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Wizard character">
      <circle cx="11" cy="28" r="2" fill="#E8B84B" opacity="0.7" />
      <circle cx="109" cy="22" r="1.5" fill="#E8B84B" opacity="0.5" />
      <circle cx="113" cy="60" r="1" fill="#7C6FF7" opacity="0.6" />
      <circle cx="7" cy="64" r="1.5" fill="#7C6FF7" opacity="0.5" />
      <path d="M60 4L33 72h54Z" fill="#1B1624" />
      <rect x="25" y="70" width="70" height="12" rx="6" fill="#2D2840" />
      <text x="51" y="52" fontSize="11" fill="#E8B84B">★</text>
      <text x="57" y="32" fontSize="7" fill="#E8B84B" opacity="0.55">✦</text>
      <circle cx="60" cy="97" r="23" fill="#F5D2A0" />
      <ellipse cx="52" cy="93" rx="3.2" ry="3.8" fill="#1B1624" />
      <ellipse cx="68" cy="93" rx="3.2" ry="3.8" fill="#1B1624" />
      <circle cx="53.5" cy="91" r="1.2" fill="white" />
      <circle cx="69.5" cy="91" r="1.2" fill="white" />
      <ellipse cx="60" cy="100" rx="2.5" ry="2" fill="#DDAA72" />
      <path d="M52 108Q60 115 68 108" stroke="#1B1624" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <ellipse cx="44" cy="101" rx="7" ry="4.5" fill="#F08880" opacity="0.32" />
      <ellipse cx="76" cy="101" rx="7" ry="4.5" fill="#F08880" opacity="0.32" />
      <path d="M44 112Q46 134 60 136Q74 134 76 112Z" fill="#C8B99A" />
      <path d="M36 120L22 152h76l-14-32Z" fill="#1B1624" />
      <path d="M52 120L47 152h26l-5-32Z" fill="#2D2840" />
      <path d="M36 122L21 142" stroke="#1B1624" strokeWidth="10" strokeLinecap="round" />
      <circle cx="20" cy="143" r="7.5" fill="#F5D2A0" />
      <path d="M84 122L96 133" stroke="#1B1624" strokeWidth="10" strokeLinecap="round" />
      <line x1="94" y1="127" x2="110" y2="152" stroke="#9B8560" strokeWidth="4" strokeLinecap="round" />
      <circle cx="92" cy="123" r="11" fill="#7C6FF7" opacity="0.88" />
      <circle cx="88" cy="119" r="4.5" fill="white" opacity="0.32" />
      <circle cx="80" cy="110" r="2.2" fill="#E8B84B" opacity="0.9" />
      <circle cx="85" cy="99" r="1.6" fill="#E8B84B" opacity="0.7" />
      <circle cx="73" cy="108" r="1.4" fill="#7C6FF7" opacity="0.65" />
    </svg>
  );
}

// ─── Gift SVG ─────────────────────────────────────────────────────────────────

function GiftSVG() {
  return (
    <svg viewBox="0 0 200 180" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-52 h-auto mx-auto" aria-label="Gift box">
      <ellipse cx="100" cy="174" rx="62" ry="8" fill="black" opacity="0.04" />
      <rect x="24" y="76" width="152" height="94" rx="8" fill="#F9F6F3" stroke="#1B1624" strokeWidth="2.5" />
      <rect x="15" y="54" width="170" height="26" rx="8" fill="#1B1624" />
      <rect x="88" y="54" width="24" height="116" fill="#E8B84B" />
      <rect x="15" y="62" width="170" height="12" fill="#E8B84B" />
      <path d="M88 56Q56 30 64 14Q76 0 88 26Z" fill="#E8B84B" />
      <path d="M112 56Q144 30 136 14Q124 0 112 26Z" fill="#E8B84B" />
      <circle cx="100" cy="46" r="11" fill="#D4941A" />
      <circle cx="97" cy="43" r="4.5" fill="#E8B84B" opacity="0.5" />
      <text x="36" y="42" fontSize="15" fill="#E8B84B" opacity="0.7">✦</text>
      <text x="158" y="38" fontSize="12" fill="#7C6FF7" opacity="0.6">✦</text>
    </svg>
  );
}

// ─── Crystal Ball SVG ─────────────────────────────────────────────────────────

function CrystalSVG({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 140 158" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-40 h-auto mx-auto" aria-label="Crystal ball">
      <ellipse cx="70" cy="150" rx="36" ry="9" fill="black" opacity="0.055" />
      <path d="M48 128Q70 142 92 128L97 135Q70 157 43 135Z" fill="#C8B89A" />
      <ellipse cx="70" cy="129" rx="27" ry="8" fill="#D4C5A9" />
      <circle cx="70" cy="70" r="64" fill={color} opacity="0.1" />
      <circle cx="70" cy="70" r="57" fill="white" />
      <circle cx="70" cy="70" r="57" fill={color} opacity="0.42" />
      <circle cx="70" cy="70" r="36" fill={color} opacity="0.18" />
      <ellipse cx="52" cy="50" rx="18" ry="13" fill="white" opacity="0.55" transform="rotate(-20 52 50)" />
      <circle cx="46" cy="46" r="9" fill="white" opacity="0.38" />
      <text x="50" y="86" fontSize="30" opacity="0.78">✨</text>
    </svg>
  );
}

// ─── Gong Display ─────────────────────────────────────────────────────────────

function GongDisplay({ glowing }: { glowing: boolean }) {
  return (
    <div className="relative flex items-center justify-center">
      {/* Ambient glow behind gong disc (top portion of image) */}
      <motion.div
        className="absolute pointer-events-none"
        style={{
          width: "55%",
          aspectRatio: "1",
          top: "0%",
          left: "22.5%",
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(232,184,75,0.45) 0%, rgba(124,111,247,0.3) 45%, transparent 72%)",
        }}
        animate={
          glowing
            ? { scale: [1, 1.14, 1], opacity: [0.6, 1, 0.6] }
            : { opacity: 0.12 }
        }
        transition={glowing ? { repeat: Infinity, duration: 2.6, ease: "easeInOut" } : {}}
      />

      {/* Blue aura ring (resting, always visible) */}
      <div
        className="absolute pointer-events-none rounded-full border"
        style={{
          width: "52%",
          aspectRatio: "1",
          top: "1%",
          left: "24%",
          borderColor: glowing ? "rgba(124,111,247,0.5)" : "rgba(124,111,247,0.18)",
          transition: "border-color 0.8s ease",
        }}
      />

      {/* Ripple waves when glowing */}
      {glowing &&
        [0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="absolute pointer-events-none rounded-full"
            style={{
              width: "52%",
              aspectRatio: "1",
              top: "1%",
              left: "24%",
              border: `${i === 0 ? 2 : 1}px solid`,
              borderColor:
                i % 2 === 0
                  ? "rgba(124,111,247,0.65)"
                  : "rgba(232,184,75,0.5)",
            }}
            animate={{
              width: ["52%", "95%"],
              left: ["24%", "2.5%"],
              top: ["1%", "-20%"],
              opacity: [0.7, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 2.8,
              delay: i * 0.93,
              ease: "easeOut",
            }}
          />
        ))}

      {/* The sketch image — multiply blend makes the paper transparent */}
      <img
        src={gongImage}
        alt="Sacred meditation gong with crystal base"
        className="relative z-10 w-full h-auto"
        style={{
          mixBlendMode: "multiply",
          filter: glowing
            ? "saturate(1.5) contrast(1.15) brightness(1.08) drop-shadow(0 0 12px rgba(124,111,247,0.4))"
            : "saturate(0.75) contrast(1.0) brightness(0.92)",
          transition: "filter 1.2s ease",
        }}
      />
    </div>
  );
}

// ─── Cupboard components ──────────────────────────────────────────────────────

function CupboardCrystal({ crystal, size = 44 }: { crystal: Crystal; size?: number }) {
  return (
    <motion.div
      className="flex flex-col items-center gap-1.5"
      animate={crystal.isNew ? { y: [0, -4, 0] } : {}}
      transition={{ repeat: Infinity, duration: 2.8, ease: "easeInOut" }}
    >
      <div
        className="rounded-full flex items-center justify-center relative flex-shrink-0"
        style={{
          width: size,
          height: size,
          background: `radial-gradient(circle at 35% 32%, white 0%, ${crystal.color} 100%)`,
          boxShadow: crystal.isNew
            ? `0 0 20px ${crystal.color}99, 0 0 40px ${crystal.color}44`
            : "0 2px 8px rgba(0,0,0,0.18)",
        }}
      >
        {crystal.isNew && (
          <div
            className="absolute inset-0 rounded-full animate-pulse"
            style={{ boxShadow: `0 0 16px ${crystal.color}88` }}
          />
        )}
        <span className="text-base leading-none">✨</span>
      </div>
      <p
        className="text-center leading-tight"
        style={{
          fontSize: 9,
          color: crystal.isNew ? "#E8B84B" : "rgba(255,255,255,0.45)",
          maxWidth: size + 8,
          fontWeight: crystal.isNew ? 600 : 400,
        }}
      >
        {crystal.isNew ? `★ ${crystal.name}` : crystal.name}
      </p>
    </motion.div>
  );
}

function EmptyCupboardSlot({ size = 44 }: { size?: number }) {
  return (
    <div
      className="rounded-full border border-dashed flex-shrink-0"
      style={{ width: size, height: size, borderColor: "rgba(255,255,255,0.1)" }}
    />
  );
}

function ShelfPlank() {
  return (
    <div
      className="h-2.5 rounded"
      style={{
        background: "linear-gradient(180deg, #9E7A50 0%, #7A5E38 100%)",
        boxShadow: "0 2px 6px rgba(0,0,0,0.3)",
      }}
    />
  );
}

// Single-collection cupboard (used after journaling)
function MagicalCupboard({ crystals }: { crystals: Crystal[] }) {
  const slots: (Crystal | null)[] = Array(6).fill(null);
  crystals.forEach((c, i) => { if (i < 6) slots[i] = c; });
  const rows = [slots.slice(0, 3), slots.slice(3, 6)];

  return (
    <div className="w-full max-w-[304px] mx-auto">
      <div
        className="rounded-2xl overflow-hidden"
        style={{
          background: "linear-gradient(180deg, #A48060 0%, #7A6045 100%)",
          boxShadow: "0 8px 40px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.1)",
          border: "3px solid #5E3D22",
        }}
      >
        <div className="px-5 py-3 flex items-center gap-2" style={{ background: "rgba(0,0,0,0.22)" }}>
          <div className="flex-1 h-px" style={{ background: "rgba(232,184,75,0.38)" }} />
          <span style={{ color: "#E8B84B", fontSize: 11, letterSpacing: "0.16em", fontWeight: 600 }}>✦ COLLECTION ✦</span>
          <div className="flex-1 h-px" style={{ background: "rgba(232,184,75,0.38)" }} />
        </div>
        <div className="px-5 py-4 flex flex-col gap-4" style={{ background: "#18122E" }}>
          {rows.map((row, ri) => (
            <div key={ri}>
              <div className="flex justify-around items-end mb-3">
                {row.map((crystal, ci) =>
                  crystal ? (
                    <CupboardCrystal key={ci} crystal={crystal} />
                  ) : (
                    <div key={ci} className="flex flex-col items-center gap-1.5">
                      <EmptyCupboardSlot />
                      <div style={{ width: 52, height: 10 }} />
                    </div>
                  )
                )}
              </div>
              <ShelfPlank />
            </div>
          ))}
        </div>
        <div className="px-6 py-2.5 flex justify-between items-center" style={{ background: "rgba(0,0,0,0.28)" }}>
          <div className="w-5 h-5 rounded-full" style={{ background: "linear-gradient(135deg, #B89060 0%, #8B6838 100%)", border: "1px solid rgba(232,184,75,0.4)" }} />
          <div className="flex-1 mx-4 h-1.5 rounded-full" style={{ background: "rgba(232,184,75,0.15)" }} />
          <div className="w-5 h-5 rounded-full" style={{ background: "linear-gradient(135deg, #B89060 0%, #8B6838 100%)", border: "1px solid rgba(232,184,75,0.4)" }} />
        </div>
      </div>
    </div>
  );
}

// Two-sided cupboard (final screen: journals left, meditations right)
function FinalMagicalCupboard({
  journalCrystals,
  medCrystals,
}: {
  journalCrystals: Crystal[];
  medCrystals: Crystal[];
}) {
  const jSlots: (Crystal | null)[] = [
    ...journalCrystals.slice(-3),
    ...Array(Math.max(0, 3 - journalCrystals.length)).fill(null),
  ];
  const mSlots: (Crystal | null)[] = [
    ...medCrystals.slice(-3),
    ...Array(Math.max(0, 3 - medCrystals.length)).fill(null),
  ];

  const CrystalOrEmpty = ({ c, side }: { c: Crystal | null; side: "j" | "m" }) =>
    c ? (
      <CupboardCrystal crystal={c} size={38} />
    ) : (
      <div className="flex flex-col items-center gap-1.5">
        <EmptyCupboardSlot size={38} />
        <div style={{ width: 46, height: 10 }} />
      </div>
    );

  return (
    <div className="w-full max-w-[340px] mx-auto">
      <div
        className="rounded-2xl overflow-hidden"
        style={{
          background: "linear-gradient(180deg, #A48060 0%, #7A6045 100%)",
          boxShadow: "0 8px 40px rgba(0,0,0,0.18)",
          border: "3px solid #5E3D22",
        }}
      >
        {/* Top bar */}
        <div className="px-5 py-3 flex items-center gap-2" style={{ background: "rgba(0,0,0,0.22)" }}>
          <div className="flex-1 h-px" style={{ background: "rgba(232,184,75,0.38)" }} />
          <span style={{ color: "#E8B84B", fontSize: 11, letterSpacing: "0.14em", fontWeight: 600 }}>
            ✦ COLLECTION ✦
          </span>
          <div className="flex-1 h-px" style={{ background: "rgba(232,184,75,0.38)" }} />
        </div>

        {/* Two panels side by side */}
        <div className="flex" style={{ background: "#18122E" }}>
          {/* LEFT: Journal crystals */}
          <div className="flex-1 px-3 pt-4 pb-3">
            <p
              className="text-center text-[9px] tracking-widest uppercase font-semibold mb-3"
              style={{ color: "rgba(232,184,75,0.6)", letterSpacing: "0.18em" }}
            >
              Journal
            </p>
            <div className="flex justify-around items-end mb-2">
              {jSlots.map((c, i) => (
                <CrystalOrEmpty key={i} c={c} side="j" />
              ))}
            </div>
            <ShelfPlank />
          </div>

          {/* Divider */}
          <div className="w-px my-2" style={{ background: "rgba(154,125,80,0.45)" }} />

          {/* RIGHT: Meditation crystals */}
          <div className="flex-1 px-3 pt-4 pb-3">
            <p
              className="text-center text-[9px] tracking-widest uppercase font-semibold mb-3"
              style={{ color: "rgba(164,139,250,0.75)", letterSpacing: "0.18em" }}
            >
              Meditation
            </p>
            <div className="flex justify-around items-end mb-2">
              {mSlots.map((c, i) => (
                <CrystalOrEmpty key={i} c={c} side="m" />
              ))}
            </div>
            <ShelfPlank />
          </div>
        </div>

        {/* Bottom base */}
        <div className="px-6 py-2.5 flex justify-between items-center" style={{ background: "rgba(0,0,0,0.28)" }}>
          <div className="w-5 h-5 rounded-full" style={{ background: "linear-gradient(135deg, #B89060 0%, #8B6838 100%)", border: "1px solid rgba(232,184,75,0.4)" }} />
          <div className="flex-1 mx-4 h-1.5 rounded-full" style={{ background: "rgba(232,184,75,0.15)" }} />
          <div className="w-5 h-5 rounded-full" style={{ background: "linear-gradient(135deg, #B89060 0%, #8B6838 100%)", border: "1px solid rgba(232,184,75,0.4)" }} />
        </div>
      </div>
    </div>
  );
}

// ─── Screens ──────────────────────────────────────────────────────────────────

function MoodScreen({ selected, onSelect, onNext }: {
  selected: string | null;
  onSelect: (id: string) => void;
  onNext: () => void;
}) {
  return (
    <motion.div key="mood" variants={SLIDE} initial="enter" animate="center" exit="exit" transition={{ duration: 0.32 }} className="flex flex-col h-full">
      <div className="relative flex-shrink-0 px-6 pt-14 pb-8" style={GRID}>
        <svg className="absolute inset-0 size-full pointer-events-none" aria-hidden>
          <line x1="0" y1="0" x2="100%" y2="100%" stroke="rgba(27,22,36,0.055)" strokeWidth="1.5" />
        </svg>
        <div className="relative z-10 flex items-end gap-3 mb-6">
          <WizardSVG className="w-14 h-auto flex-shrink-0" />
          <div className="flex-1 rounded-2xl rounded-bl-sm px-4 py-3 border" style={{ background: "#fff", borderColor: "rgba(27,22,36,0.07)", boxShadow: "0 1px 8px rgba(27,22,36,0.06)" }}>
            <p className="text-[13px] leading-relaxed" style={{ color: "#6B6880" }}>Hello! I'm Aldric. I'll be with you through today's entry. ✨</p>
          </div>
        </div>
        <div className="relative z-10">
          <h1 className="text-[26px] font-semibold leading-tight" style={{ color: "#1B1624" }}>How are you feeling<br />right now?</h1>
          <p className="text-sm mt-1.5" style={{ color: "#9896A4" }}>Choose the emotion closest to you.</p>
        </div>
      </div>
      <div className="flex-1 flex flex-col px-4 pt-5 pb-6 overflow-y-auto" style={{ background: "#EDE9E3" }}>
        <div className="grid grid-cols-2 gap-2.5 flex-1">
          {EMOTIONS.map((e, i) => {
            const isSelected = selected === e.id;
            const isLastOdd = i === EMOTIONS.length - 1 && EMOTIONS.length % 2 !== 0;
            return (
              <motion.button key={e.id} onClick={() => onSelect(e.id)} whileTap={{ scale: 0.96 }}
                className={`flex items-center gap-3 px-4 py-3.5 rounded-full text-left transition-all duration-200 ${isLastOdd ? "col-span-2 justify-center" : ""}`}
                style={{ background: isSelected ? "#1B1624" : "#fff", boxShadow: isSelected ? "0 2px 16px rgba(27,22,36,0.24)" : "none", maxWidth: isLastOdd ? "calc(50% - 5px)" : undefined, marginInline: isLastOdd ? "auto" : undefined }}
              >
                <span className="w-9 h-9 rounded-full flex items-center justify-center text-xl flex-shrink-0" style={{ background: isSelected ? "rgba(255,255,255,0.18)" : "#EDE9E3" }}>{e.emoji}</span>
                <span className="text-[15px] font-medium" style={{ color: isSelected ? "#fff" : "#1B1624" }}>{e.label}</span>
              </motion.button>
            );
          })}
        </div>
        <motion.button onClick={onNext} disabled={!selected} whileTap={{ scale: 0.98 }}
          className="mt-5 w-full py-4 rounded-full font-semibold text-[15px] transition-all duration-200 disabled:opacity-30 disabled:cursor-not-allowed"
          style={{ background: "#1B1624", color: "#fff", boxShadow: selected ? "0 4px 20px rgba(27,22,36,0.28)" : "none" }}
        >Continue →</motion.button>
      </div>
    </motion.div>
  );
}

function QuestionScreen({ emotion, selected, onSelect, onNext }: {
  emotion: Emotion; selected: string | null;
  onSelect: (a: string) => void; onNext: () => void;
}) {
  const letters = ["A", "B", "C", "D"];
  return (
    <motion.div key="question" variants={SLIDE} initial="enter" animate="center" exit="exit" transition={{ duration: 0.32 }} className="flex flex-col h-full">
      <div className="flex-1 flex flex-col px-6 pt-12 pb-6" style={GRID}>
        <div className="flex items-center gap-2 mb-7">
          <span className="text-3xl">{emotion.emoji}</span>
          <span className="text-sm font-medium" style={{ color: "#9896A4" }}>{emotion.label}</span>
        </div>
        <div className="flex items-start gap-4 flex-1">
          <motion.div animate={{ y: [0, -4, 0] }} transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut" }} className="flex-shrink-0">
            <WizardSVG className="w-16 h-auto" />
          </motion.div>
          <div className="flex-1 pt-2">
            <p className="text-[11px] font-semibold tracking-widest uppercase mb-2.5" style={{ color: "#9896A4" }}>Aldric asks</p>
            <h2 className="text-[21px] font-semibold leading-snug" style={{ color: "#1B1624" }}>{emotion.question}</h2>
          </div>
        </div>
      </div>
      <div className="flex-shrink-0 px-4 pt-5 pb-6" style={{ background: "#EDE9E3" }}>
        <div className="flex flex-col gap-2.5 mb-5">
          {emotion.options.map((option, i) => {
            const isSelected = selected === option;
            return (
              <motion.button key={option} onClick={() => onSelect(option)} whileTap={{ scale: 0.98 }}
                className="flex items-center gap-4 px-4 py-4 rounded-2xl text-left transition-all duration-200"
                style={{ background: isSelected ? "#1B1624" : "#fff", boxShadow: isSelected ? "0 2px 16px rgba(27,22,36,0.24)" : "none" }}
              >
                <span className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0" style={{ background: isSelected ? "rgba(255,255,255,0.18)" : "#EDE9E3", color: isSelected ? "#fff" : "#9896A4" }}>{letters[i]}</span>
                <span className="text-[15px] font-medium leading-snug" style={{ color: isSelected ? "#fff" : "#1B1624" }}>{option}</span>
              </motion.button>
            );
          })}
        </div>
        <motion.button onClick={onNext} disabled={!selected} whileTap={{ scale: 0.98 }}
          className="w-full py-4 rounded-full font-semibold text-[15px] transition-all duration-200 disabled:opacity-30 disabled:cursor-not-allowed"
          style={{ background: "#1B1624", color: "#fff", boxShadow: selected ? "0 4px 20px rgba(27,22,36,0.28)" : "none" }}
        >Continue →</motion.button>
      </div>
    </motion.div>
  );
}

function JournalScreen({ emotion, text, onChange, onClear, onNext }: {
  emotion: Emotion; text: string;
  onChange: (v: string) => void; onClear: () => void; onNext: () => void;
}) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { textareaRef.current?.focus(); }, []);
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  return (
    <motion.div key="journal" variants={SLIDE} initial="enter" animate="center" exit="exit" transition={{ duration: 0.32 }} className="flex flex-col h-full">
      <div className="flex items-center gap-3 px-5 py-4 flex-shrink-0" style={{ background: "#1B1624" }}>
        <span className="text-2xl">{emotion.emoji}</span>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] tracking-widest uppercase mb-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>Your Journal</p>
          <p className="text-sm font-medium truncate" style={{ color: "rgba(255,255,255,0.75)" }}>
            {emotion.label} — {new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short" })}
          </p>
        </div>
        <button onClick={onClear} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.1)" }} aria-label="Clear">
          <X className="w-4 h-4" style={{ color: "rgba(255,255,255,0.55)" }} />
        </button>
      </div>
      <div className="relative flex-1 flex flex-col" style={{ background: "#F9F6F3" }}>
        <div className="absolute left-5 top-5 bottom-5 w-0.5 rounded-full" style={{ background: "#E8B84B", opacity: 0.65 }} />
        <textarea
          ref={textareaRef} value={text} onChange={(e) => onChange(e.target.value)}
          placeholder={emotion.prompt} className="flex-1 resize-none bg-transparent focus:outline-none"
          style={{ paddingTop: 24, paddingBottom: 16, paddingLeft: 36, paddingRight: 24, fontSize: 26, lineHeight: 1.55, color: "#1B1624", fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 400, scrollbarWidth: "none" }}
        />
        <div className="flex items-center justify-between pb-4" style={{ paddingLeft: 36, paddingRight: 24 }}>
          <span className="text-xs" style={{ color: "#C8C4D0" }}>{wordCount > 0 ? `${wordCount} ${wordCount === 1 ? "word" : "words"}` : "Start writing…"}</span>
          <AnimatePresence>
            {wordCount > 0 && (
              <motion.button onClick={onNext} initial={{ opacity: 0, scale: 0.88 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.88 }} whileTap={{ scale: 0.96 }}
                className="flex items-center gap-1.5 rounded-full font-semibold text-sm"
                style={{ background: "#1B1624", color: "#fff", paddingInline: 16, paddingBlock: 8, boxShadow: "0 2px 12px rgba(27,22,36,0.22)" }}
              >Done <ArrowRight className="w-3.5 h-3.5" /></motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>
      <div className="flex-shrink-0 px-5 py-5" style={{ background: "#2D2840" }}>
        <div className="flex items-center gap-4">
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 3.2, ease: "easeInOut" }} className="flex-shrink-0">
            <WizardSVG className="w-14 h-auto" />
          </motion.div>
          <div className="flex-1">
            <p className="text-[10px] font-semibold tracking-widest uppercase mb-1" style={{ color: "#E8B84B" }}>Aldric whispers</p>
            <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.68)" }}>Take your time. Every word you write is a small act of courage.</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function WizardTransitionScreen({ onNext }: { onNext: () => void }) {
  const [showButton, setShowButton] = useState(false);
  useEffect(() => { const t = setTimeout(() => setShowButton(true), 2000); return () => clearTimeout(t); }, []);
  return (
    <motion.div key="wizard-transition" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      className="relative flex flex-col items-center justify-center h-full px-8 text-center" style={GRID}
    >
      {[0, 1, 2, 3, 4].map((i) => (
        <motion.span key={i} className="absolute select-none pointer-events-none"
          style={{ left: `${14 + i * 18}%`, top: `${24 + (i % 3) * 10}%`, color: i % 2 === 0 ? "#E8B84B" : "#7C6FF7", fontSize: 14 + (i % 2) * 4 }}
          animate={{ opacity: [0, 1, 0], y: [0, -28, -56], scale: [0.8, 1.2, 0.8] }}
          transition={{ repeat: Infinity, duration: 2.8, delay: i * 0.55, ease: "easeOut" }}
        >✦</motion.span>
      ))}
      <motion.div animate={{ rotate: [-3, 3, -3], y: [0, -8, 0] }} transition={{ repeat: Infinity, duration: 3.2, ease: "easeInOut" }}>
        <WizardSVG className="w-40 h-auto" />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-8">
        <p className="text-[11px] tracking-widest uppercase mb-3" style={{ color: "#9896A4" }}>Aldric is working his magic</p>
        <h2 className="text-[22px] font-semibold leading-snug" style={{ color: "#1B1624" }}>Weaving your words<br />into something special…</h2>
      </motion.div>
      <AnimatePresence>
        {showButton && (
          <motion.button initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} onClick={onNext} whileTap={{ scale: 0.97 }}
            className="mt-10 px-10 py-4 rounded-full font-semibold text-[15px]"
            style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
          >See what appeared →</motion.button>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function GiftScreen({ onNext }: { onNext: () => void }) {
  return (
    <motion.div key="gift" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      className="flex flex-col items-center justify-center h-full px-8 text-center" style={GRID}
    >
      <p className="text-[11px] tracking-widest uppercase mb-7" style={{ color: "#9896A4" }}>A reward has appeared</p>
      <motion.div initial={{ scale: 0.78, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.2, type: "spring", stiffness: 180 }}>
        <GiftSVG />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }} className="mt-8">
        <h2 className="text-[24px] font-semibold leading-snug" style={{ color: "#1B1624" }}>Something has been<br />conjured for you.</h2>
        <p className="text-[15px] mt-3" style={{ color: "#9896A4" }}>Every time you journal, a new crystal is born.</p>
      </motion.div>
      <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1 }} onClick={onNext} whileTap={{ scale: 0.97 }}
        className="mt-10 px-10 py-4 rounded-full font-semibold text-[15px]"
        style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
      >Open gift →</motion.button>
    </motion.div>
  );
}

function RevealScreen({ emotion, onNext }: { emotion: Emotion; onNext: () => void }) {
  const { crystal } = emotion;
  return (
    <motion.div key="reveal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      className="relative flex flex-col items-center justify-center h-full px-8 text-center overflow-hidden" style={GRID}
    >
      <svg className="absolute inset-0 size-full pointer-events-none" aria-hidden>
        <line x1="100%" y1="0" x2="0" y2="100%" stroke="rgba(27,22,36,0.07)" strokeWidth="1" />
        <line x1="85%" y1="0" x2="0" y2="85%" stroke="rgba(27,22,36,0.035)" strokeWidth="0.5" />
      </svg>
      <motion.div initial={{ scale: 0, rotate: -18 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 160, delay: 0.15 }} className="relative z-10">
        <CrystalSVG color={crystal.color} />
        <div className="absolute inset-0 rounded-full blur-2xl -z-10" style={{ background: crystal.color, opacity: 0.28 }} />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="relative z-10 mt-6">
        <p className="text-[11px] tracking-widest uppercase mb-1" style={{ color: "#9896A4" }}>New crystal unlocked</p>
        <h2 className="text-[28px] font-semibold" style={{ color: "#1B1624" }}>{crystal.name}</h2>
        <p className="text-[15px] mt-3 leading-relaxed mx-auto" style={{ color: "#6B6880", maxWidth: 264 }}>{crystal.description}</p>
      </motion.div>
      <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }} onClick={onNext} whileTap={{ scale: 0.97 }}
        className="relative z-10 mt-8 px-10 py-4 rounded-full font-semibold text-[15px]"
        style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
      >See your collection →</motion.button>
    </motion.div>
  );
}

// Updated cupboard — now has "Help Aldric" as primary CTA
function CupboardScreen({ crystals, emotion, onHelpAldric, onRestart }: {
  crystals: Crystal[]; emotion: Emotion;
  onHelpAldric: () => void; onRestart: () => void;
}) {
  return (
    <motion.div key="cupboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      className="flex flex-col h-full" style={GRID}
    >
      <div className="px-6 pt-12 pb-5 flex-shrink-0">
        <p className="text-[11px] tracking-widest uppercase mb-2" style={{ color: "#9896A4" }}>Your magical wardrobe</p>
        <h2 className="text-[26px] font-semibold leading-tight" style={{ color: "#1B1624" }}>Crystal Collection</h2>
        <p className="text-sm mt-1.5" style={{ color: "#9896A4" }}>One crystal for every time you journaled.</p>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-2">
        <MagicalCupboard crystals={crystals} />
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}
          className="mt-5 flex items-center gap-2 px-4 py-2 rounded-full"
          style={{ background: emotion.crystal.color + "22", border: `1px solid ${emotion.crystal.color}55` }}
        >
          <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: emotion.crystal.color, boxShadow: `0 0 8px ${emotion.crystal.color}88` }} />
          <p className="text-sm font-medium" style={{ color: "#1B1624" }}>Today: {emotion.crystal.name} added ✦</p>
        </motion.div>
      </div>
      <div className="flex-shrink-0 px-6 pb-10">
        <div className="flex items-center gap-3 rounded-2xl p-4 mb-4" style={{ background: "#F0EDE8" }}>
          <WizardSVG className="w-10 h-auto flex-shrink-0" />
          <p className="text-[13px] leading-relaxed flex-1" style={{ color: "#6B6880" }}>
            Excellent work. Now — I have one more thing to ask of you, if you're willing… 🌟
          </p>
        </div>
        <motion.button whileTap={{ scale: 0.97 }} onClick={onHelpAldric}
          className="w-full py-4 rounded-full font-semibold text-[15px] mb-3"
          style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
        >Help Aldric with a spell ✦</motion.button>
        <button onClick={onRestart} className="w-full py-2.5 text-[14px] font-medium" style={{ color: "#9896A4" }}>
          Journal again →
        </button>
      </div>
    </motion.div>
  );
}

// ─── New screens: Spell invite ────────────────────────────────────────────────

function SpellScreen({ onAccept }: { onAccept: () => void }) {
  return (
    <motion.div key="spell" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      className="flex flex-col h-full px-8 text-center" style={GRID}
    >
      <div className="flex-1 flex flex-col items-center justify-center">
        <motion.div
          animate={{ rotate: [-6, 6, -6], y: [0, -10, 0] }}
          transition={{ repeat: Infinity, duration: 2.6, ease: "easeInOut" }}
          className="mb-7"
        >
          <WizardSVG className="w-44 h-auto" />
        </motion.div>
        <p className="text-[11px] tracking-widest uppercase mb-4" style={{ color: "#9896A4" }}>Aldric needs your help</p>
        <h2 className="text-[22px] font-semibold leading-snug mb-4" style={{ color: "#1B1624" }}>
          "I'm weaving a powerful spell — but I need someone to hold the vibration with me."
        </h2>
        <p className="text-[15px] leading-relaxed" style={{ color: "#6B6880" }}>
          Sit with the sacred gong for 90 seconds. Your stillness is the magic.
        </p>
      </div>
      <div className="pb-10">
        <motion.button whileTap={{ scale: 0.97 }} onClick={onAccept}
          className="w-full py-4 rounded-full font-semibold text-[15px]"
          style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
        >I'll help Aldric →</motion.button>
      </div>
    </motion.div>
  );
}

// ─── New screens: Gong meditation ─────────────────────────────────────────────

function GongScreen({ onComplete }: { onComplete: () => void }) {
  const [active, setActive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(90);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!active) return;
    const id = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(id);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [active]);

  // Watch for timer reaching 0
  useEffect(() => {
    if (active && timeLeft === 0) {
      setActive(false);
      setDone(true);
    }
  }, [active, timeLeft]);

  // Auto-advance after done
  useEffect(() => {
    if (!done) return;
    const t = setTimeout(onComplete, 2200);
    return () => clearTimeout(t);
  }, [done, onComplete]);

  const fmt = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <motion.div key="gong" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-between h-full px-6 pt-10 pb-10" style={GRID}
    >
      {/* Timer */}
      <div className="text-center">
        <p className="text-[11px] tracking-widest uppercase mb-2" style={{ color: done ? "#7C6FF7" : active ? "#7C6FF7" : "#9896A4" }}>
          {done ? "Complete ✦" : active ? "Hold the vibration" : "Meditation Timer"}
        </p>
        <motion.p
          className="font-semibold"
          style={{
            fontSize: 60,
            letterSpacing: "-0.02em",
            fontVariantNumeric: "tabular-nums",
            color: done ? "#7C6FF7" : active ? "#1B1624" : "#1B1624",
            lineHeight: 1,
          }}
          animate={done ? { scale: [1, 1.08, 1] } : {}}
          transition={{ duration: 0.6 }}
        >
          {fmt(timeLeft)}
        </motion.p>
        {active && (
          <motion.div className="flex justify-center gap-1 mt-3">
            {[0, 1, 2].map((i) => (
              <motion.div key={i} className="w-1 h-1 rounded-full" style={{ background: "#7C6FF7" }}
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ repeat: Infinity, duration: 1.4, delay: i * 0.46 }}
              />
            ))}
          </motion.div>
        )}
      </div>

      {/* Gong illustration */}
      <div className="w-full max-w-[280px] mx-auto">
        <GongDisplay glowing={active || done} />
      </div>

      {/* Breathe prompt or start button */}
      <div className="w-full text-center">
        {!active && !done && (
          <motion.button
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setActive(true)}
            className="w-full py-4 rounded-full font-semibold text-[15px]"
            style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
          >
            Start Meditation
          </motion.button>
        )}
        {active && (
          <motion.p
            className="text-[15px]"
            style={{ color: "#9896A4" }}
            animate={{ opacity: [0.4, 0.85, 0.4] }}
            transition={{ repeat: Infinity, duration: 4.5, ease: "easeInOut" }}
          >
            Breathe. Be still.
          </motion.p>
        )}
        {done && (
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[15px] font-semibold"
            style={{ color: "#7C6FF7" }}
          >
            ✦ Well done. A crystal forms…
          </motion.p>
        )}
      </div>
    </motion.div>
  );
}

// ─── New screens: Meditation reward reveal ────────────────────────────────────

function MeditationRevealScreen({ crystal, onNext }: { crystal: Crystal; onNext: () => void }) {
  return (
    <motion.div key="med-reveal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      className="relative flex flex-col items-center justify-center h-full px-8 text-center overflow-hidden" style={GRID}
    >
      {/* Diagonal lines */}
      <svg className="absolute inset-0 size-full pointer-events-none" aria-hidden>
        <line x1="0" y1="0" x2="100%" y2="100%" stroke="rgba(124,111,247,0.08)" strokeWidth="1" />
        <line x1="15%" y1="0" x2="100%" y2="85%" stroke="rgba(124,111,247,0.04)" strokeWidth="0.5" />
      </svg>

      <motion.div initial={{ scale: 0, rotate: 18 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 160, delay: 0.15 }} className="relative z-10">
        <CrystalSVG color={crystal.color} />
        <div className="absolute inset-0 rounded-full blur-2xl -z-10" style={{ background: crystal.color, opacity: 0.32 }} />
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="relative z-10 mt-6">
        <p className="text-[11px] tracking-widest uppercase mb-1" style={{ color: "#9896A4" }}>Meditation crystal unlocked</p>
        <h2 className="text-[28px] font-semibold" style={{ color: "#1B1624" }}>{crystal.name}</h2>
        <p className="text-[15px] mt-3 leading-relaxed mx-auto" style={{ color: "#6B6880", maxWidth: 264 }}>{crystal.description}</p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9 }}
        className="relative z-10 mt-5 flex items-center gap-2 px-4 py-2 rounded-full"
        style={{ background: crystal.color + "20", border: `1px solid ${crystal.color}55` }}
      >
        <WizardSVG className="w-7 h-auto flex-shrink-0" />
        <p className="text-[13px] italic" style={{ color: "#6B6880" }}>"The spell is complete. Thank you."</p>
      </motion.div>

      <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.3 }} onClick={onNext} whileTap={{ scale: 0.97 }}
        className="relative z-10 mt-8 px-10 py-4 rounded-full font-semibold text-[15px]"
        style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
      >Add to collection →</motion.button>
    </motion.div>
  );
}

// ─── New screens: Final two-sided cupboard ────────────────────────────────────

function FinalCupboardScreen({ journalCrystals, medCrystals, medCrystal, onRestart }: {
  journalCrystals: Crystal[];
  medCrystals: Crystal[];
  medCrystal: Crystal;
  onRestart: () => void;
}) {
  return (
    <motion.div key="final-cupboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      className="flex flex-col h-full" style={GRID}
    >
      <div className="px-6 pt-12 pb-5 flex-shrink-0">
        <p className="text-[11px] tracking-widest uppercase mb-2" style={{ color: "#9896A4" }}>Your magical wardrobe</p>
        <h2 className="text-[26px] font-semibold leading-tight" style={{ color: "#1B1624" }}>Full Collection</h2>
        <p className="text-sm mt-1.5" style={{ color: "#9896A4" }}>Journal crystals on the left. Meditation on the right.</p>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-5 pb-2">
        <FinalMagicalCupboard journalCrystals={journalCrystals} medCrystals={medCrystals} />

        {/* New meditation crystal badge */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
          className="mt-5 flex items-center gap-2 px-4 py-2 rounded-full"
          style={{ background: medCrystal.color + "22", border: `1px solid ${medCrystal.color}55` }}
        >
          <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: medCrystal.color, boxShadow: `0 0 8px ${medCrystal.color}88` }} />
          <p className="text-sm font-medium" style={{ color: "#1B1624" }}>Today: {medCrystal.name} added ✦</p>
        </motion.div>
      </div>

      <div className="flex-shrink-0 px-6 pb-10">
        <div className="flex items-center gap-3 rounded-2xl p-4 mb-5" style={{ background: "#F0EDE8" }}>
          <WizardSVG className="w-10 h-auto flex-shrink-0" />
          <p className="text-[13px] leading-relaxed flex-1" style={{ color: "#6B6880" }}>
            Your collection grows. Come back tomorrow — both shelves are waiting. 🌟
          </p>
        </div>
        <motion.button whileTap={{ scale: 0.97 }} onClick={onRestart}
          className="w-full py-4 rounded-full font-semibold text-[15px]"
          style={{ background: "#1B1624", color: "#fff", boxShadow: "0 4px 20px rgba(27,22,36,0.28)" }}
        >Start fresh →</motion.button>
      </div>
    </motion.div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [step, setStep] = useState<Step>("mood");
  const [emotionId, setEmotionId] = useState<string | null>(null);
  const [answer, setAnswer] = useState<string | null>(null);
  const [journalText, setJournalText] = useState("");
  const [journalCollection, setJournalCollection] = useState<Crystal[]>(PRIOR_CRYSTALS);
  const [medCollection, setMedCollection] = useState<Crystal[]>(PRIOR_MED_CRYSTALS);
  const [currentMedCrystal] = useState<Crystal>(() => {
    const pick = MED_CRYSTAL_POOL[Math.floor(Math.random() * MED_CRYSTAL_POOL.length)];
    return { color: pick.color, name: pick.name };
  });

  const emotion = EMOTIONS.find((e) => e.id === emotionId) ?? null;

  const handleJournalDone = () => {
    if (!emotion) return;
    setJournalCollection((prev) => [
      ...prev.map((c) => ({ ...c, isNew: false })),
      { color: emotion.crystal.color, name: emotion.crystal.name, isNew: true },
    ]);
    setStep("wizard");
  };

  const handleMedComplete = () => {
    setMedCollection((prev) => [
      ...prev.map((c) => ({ ...c, isNew: false })),
      { ...currentMedCrystal, isNew: true },
    ]);
    setStep("med-reveal");
  };

  const handleRestart = () => {
    setStep("mood");
    setEmotionId(null);
    setAnswer(null);
    setJournalText("");
    setJournalCollection((prev) => prev.map((c) => ({ ...c, isNew: false })));
    setMedCollection((prev) => prev.map((c) => ({ ...c, isNew: false })));
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ ...GRID, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <div className="relative w-full max-w-[390px] overflow-hidden" style={{ height: "100dvh", maxHeight: 852, boxShadow: "0 0 60px rgba(27,22,36,0.07)" }}>
        <AnimatePresence mode="wait">
          {step === "mood" && <MoodScreen selected={emotionId} onSelect={setEmotionId} onNext={() => emotionId && setStep("question")} />}
          {step === "question" && emotion && <QuestionScreen emotion={emotion} selected={answer} onSelect={setAnswer} onNext={() => answer && setStep("journal")} />}
          {step === "journal" && emotion && <JournalScreen emotion={emotion} text={journalText} onChange={setJournalText} onClear={() => setJournalText("")} onNext={handleJournalDone} />}
          {step === "wizard" && <WizardTransitionScreen onNext={() => setStep("gift")} />}
          {step === "gift" && <GiftScreen onNext={() => setStep("reveal")} />}
          {step === "reveal" && emotion && <RevealScreen emotion={emotion} onNext={() => setStep("cupboard")} />}
          {step === "cupboard" && emotion && (
            <CupboardScreen
              crystals={journalCollection}
              emotion={emotion}
              onHelpAldric={() => setStep("spell")}
              onRestart={handleRestart}
            />
          )}
          {step === "spell" && <SpellScreen onAccept={() => setStep("gong")} />}
          {step === "gong" && <GongScreen onComplete={handleMedComplete} />}
          {step === "med-reveal" && <MeditationRevealScreen crystal={{ ...currentMedCrystal, isNew: true }} onNext={() => setStep("final-cupboard")} />}
          {step === "final-cupboard" && (
            <FinalCupboardScreen
              journalCrystals={journalCollection}
              medCrystals={medCollection}
              medCrystal={{ ...currentMedCrystal, isNew: true }}
              onRestart={handleRestart}
            />
          )}
        </AnimatePresence>
      </div>
      <style>{`
        textarea::-webkit-scrollbar { display: none; }
        * { scrollbar-width: none; }
      `}</style>
    </div>
  );
}
